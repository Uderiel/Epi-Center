﻿param([string]$Root,[Parameter(Mandatory=$true)][string]$RepoRoot)
$profile=Join-Path $Root ('device-profile-'+[guid]::NewGuid().ToString('N'))
$browser=Start-Process -FilePath 'C:/Program Files/Google/Chrome/Application/chrome.exe' -ArgumentList @('--headless=new','--disable-gpu','--no-first-run','--no-default-browser-check','--disable-background-networking','--remote-debugging-port=0',('--user-data-dir="'+$profile+'"'),'about:blank') -WindowStyle Hidden -PassThru -RedirectStandardError (Join-Path $Root 'device-driver-errors.txt')
$portFile=Join-Path $profile 'DevToolsActivePort'
for($attempt=0;$attempt -lt 50 -and -not(Test-Path -LiteralPath $portFile);$attempt++){Start-Sleep -Milliseconds 100}
if(-not(Test-Path -LiteralPath $portFile)){throw 'Disposable Chrome debugging endpoint unavailable'}
$debugPort=[IO.File]::ReadAllLines($portFile)[0]
$pages=Invoke-RestMethod -Uri ('http://127.0.0.1:'+$debugPort+'/json/list') -TimeoutSec 5
$page=$pages | Where-Object {$_.type -eq 'page'} | Select-Object -First 1
$socket864=[Net.WebSockets.ClientWebSocket]::new()
$socket864.ConnectAsync([uri]$page.webSocketDebuggerUrl,[Threading.CancellationToken]::None).GetAwaiter().GetResult() | Out-Null
$script:sequence864=0
function Send-Cdp864([string]$method,$parameters){
 $script:sequence864++;$sequence=$script:sequence864
 $payload=@{id=$sequence;method=$method;params=$parameters} | ConvertTo-Json -Depth 20 -Compress
 $bytes=[Text.Encoding]::UTF8.GetBytes($payload)
 $socket864.SendAsync([ArraySegment[byte]]::new($bytes),[Net.WebSockets.WebSocketMessageType]::Text,$true,[Threading.CancellationToken]::None).GetAwaiter().GetResult() | Out-Null
 while($true){
  $stream=[IO.MemoryStream]::new();$buffer=New-Object byte[] 65536
  do{$received=$socket864.ReceiveAsync([ArraySegment[byte]]::new($buffer),[Threading.CancellationToken]::None).GetAwaiter().GetResult();$stream.Write($buffer,0,$received.Count)}while(-not $received.EndOfMessage)
  $message=[Text.Encoding]::UTF8.GetString($stream.ToArray()) | ConvertFrom-Json;$stream.Dispose()
  if($message.id -eq $sequence){if($message.error){throw ($message.error | ConvertTo-Json -Compress)};return $message}
 }
}
$serverProcess=$null
try{
 $portFile=Join-Path $Root ('http-port-'+[guid]::NewGuid().ToString('N')+'.txt')
 # Repository root supplied explicitly by release runner.
 $serverProcess=Start-Process -FilePath powershell.exe -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',(Join-Path $Root 'local-server.ps1'),'-RepoRoot',$repoRoot,'-PortFile',$portFile) -WindowStyle Hidden -PassThru -RedirectStandardError (Join-Path $Root 'http-server-errors.txt')
 for($attempt=0;$attempt -lt 50 -and -not(Test-Path $portFile);$attempt++){Start-Sleep -Milliseconds 100}
 if(-not(Test-Path $portFile)){throw 'Local read-only server unavailable'}
 $port=[IO.File]::ReadAllText($portFile);$base='http://127.0.0.1:'+$port+'/Epi-Center/'
 Send-Cdp864 'Emulation.setDeviceMetricsOverride' @{width=390;height=844;deviceScaleFactor=1;mobile=$true} | Out-Null
 Send-Cdp864 'Page.enable' @{} | Out-Null
 Send-Cdp864 'Page.addScriptToEvaluateOnNewDocument' @{source="window.rootErrors865=[];window.addEventListener('error',e=>rootErrors865.push(e.message));"} | Out-Null
 function Navigate-Root865([string]$url){
  Send-Cdp864 'Page.navigate' @{url=$url} | Out-Null
  for($i=0;$i -lt 100;$i++){
   Start-Sleep -Milliseconds 100
   $expectedUrl=$url | ConvertTo-Json -Compress
   try{$ready=Send-Cdp864 'Runtime.evaluate' @{expression="location.href===$expectedUrl&&document.readyState==='complete'&&typeof appearanceUI864==='object'&&Array.isArray(window.rootErrors865)&&document.title.includes('v0.8.67')";returnByValue=$true}}catch{if($_.Exception.Message -match 'navigated|context|closed'){continue};throw}
   if($ready.result.result.value){return}
  }
  $diag=Send-Cdp864 'Runtime.evaluate' @{expression="JSON.stringify({url:location.href,title:document.title,errors:window.rootErrors865,text:document.body.innerText.slice(0,700)})";returnByValue=$true}; throw ($diag | ConvertTo-Json -Depth 6)
 }
 $candidate=$base+'epi-center-v0.8.67-reusable-autonomy-foundation.html'
 Navigate-Root865 $candidate
 function Eval866([string]$js){
  $r=Send-Cdp864 'Runtime.evaluate' @{expression=$js;returnByValue=$true}
  if($r.result.exceptionDetails){throw ($r.result.exceptionDetails | ConvertTo-Json -Depth 7)}
  return $r.result.result.value
 }

 Eval866 @"
document.getElementById('name').value='Footwear Matrix Tester';start({preventDefault(){}});
document.getElementById('prof_age').value='32';document.getElementById('prof_gender').value='Male';saveProfile({preventDefault(){}});
s.location='courtyard';takeHeels63();h63().mastered=true;sessionStorage.setItem('matrixResults867','[]');
"@ | Out-Null
 foreach($phase in @('ordinary-1','ordinary-2','cursed','stored','carried')){
  $j=Eval866 @"
(()=>{const r=JSON.parse(sessionStorage.getItem('matrixResults867')),check=(name,pass)=>{r.push({name:'${phase}: '+name,pass:!!pass});if(!pass)throw Error(name);},object=items850().objects['shoes-0'],original=JSON.stringify(anatomyInit65());
if('$phase'==='ordinary-1'){itemAction850('wear','shoes-4');itemAction850('wear','shoes-5');check('ordinary versus ordinary is blocked',items850().objects['shoes-4'].location==='equipped'&&items850().objects['shoes-5'].location!=='equipped');wearHeels63();check('cursed versus ordinary is blocked',!h63().worn&&object.location==='inventory');}
if('$phase'==='ordinary-2'){itemAction850('unequip','shoes-4');itemAction850('return','shoes-4');itemAction850('wear','shoes-5');check('ordinary unequip and storage retain objects',items850().objects['shoes-4'].location==='closet-shoes'&&items850().objects['shoes-5'].location==='equipped');}
if('$phase'==='cursed'){itemAction850('unequip','shoes-5');itemAction850('return','shoes-5');wearHeels63();itemAction850('wear','shoes-4');check('ordinary versus cursed is blocked',h63().worn&&object.location==='equipped'&&items850().objects['shoes-4'].location!=='equipped');}
if('$phase'==='stored'){removeHeels63();itemAction850('return','shoes-0');check('cursed pair stores without reversing transformation',!h63().worn&&object.location==='closet-shoes'&&JSON.stringify(anatomyInit65())===original);}
if('$phase'==='carried'){itemAction850('carry','shoes-0');check('same cursed pair retrieved without equip or reversal',!h63().worn&&object.location==='inventory'&&JSON.stringify(anatomyInit65())===original);}
check('only one physical footwear pair equipped',CATALOG850.filter(d=>d.slot==='shoes'&&items850().objects[d.id].location==='equipped').length<=1);
check('unique cursed identity and ownership retained',CATALOG850.filter(d=>d.id==='shoes-0').length===1&&item850('shoes-0').kind==='cursed'&&item850('shoes-0').slot==='shoes'&&h63().owned&&s.inventory['Erin\u2019s Red Heels']===1);
save();sessionStorage.setItem('matrixBefore867',JSON.stringify({objects:items850().objects,owned:h63().owned,worn:h63().worn,anatomy:anatomyInit65()}));sessionStorage.setItem('matrixResults867',JSON.stringify(r));return true;})();
"@
  Navigate-Root865 $candidate
  Eval866 @"
(()=>{const r=JSON.parse(sessionStorage.getItem('matrixResults867')),expected=sessionStorage.getItem('matrixBefore867'),actual=JSON.stringify({objects:items850().objects,owned:h63().owned,worn:h63().worn,anatomy:anatomyInit65()});const pass=expected===actual&&item850('shoes-0').kind==='cursed'&&rootErrors865.length===0;r.push({name:'$phase actual reload preserves physical items and curse state',pass});if(!pass)throw Error('Reload state changed');sessionStorage.setItem('matrixResults867',JSON.stringify(r));})();
"@ | Out-Null
 }
 $j=Eval866 "JSON.stringify({results:JSON.parse(sessionStorage.getItem('matrixResults867'))})"
 [IO.File]::WriteAllText((Join-Path $Root 'footwear-matrix-results.json'),$j);$d=$j|ConvertFrom-Json;'Footwear matrix checks: '+($d.results|Where-Object pass).Count+'/'+$d.results.Count
}finally{
 if($socket864.State -eq [Net.WebSockets.WebSocketState]::Open){try{Send-Cdp864 'Browser.close' @{} | Out-Null}catch{}}
 $socket864.Dispose();if($serverProcess -and -not $serverProcess.HasExited){Stop-Process -Id $serverProcess.Id}
}
