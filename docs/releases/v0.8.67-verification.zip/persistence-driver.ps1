﻿param([string]$Root,[Parameter(Mandatory=$true)][string]$RepoRoot)
$profile=Join-Path $Root ('device-profile-'+[guid]::NewGuid().ToString('N'))
$browser=Start-Process -FilePath 'C:/Program Files/Google/Chrome/Application/chrome.exe' -ArgumentList @('--headless=new','--disable-gpu','--no-first-run','--no-default-browser-check','--disable-background-networking','--remote-debugging-port=0',('--user-data-dir="'+$profile+'"'),'about:blank') -WindowStyle Hidden -PassThru -RedirectStandardError (Join-Path $Root 'device-driver-errors.txt')
$portFile=Join-Path $profile 'DevToolsActivePort'
for($attempt=0;$attempt -lt 50 -and -not(Test-Path -LiteralPath $portFile);$attempt++){Start-Sleep -Milliseconds 100}
if(-not(Test-Path -LiteralPath $portFile)){throw 'Disposable Chrome debugging endpoint unavailable'}
$debugPort=[IO.File]::ReadAllLines($portFile)[0]
$pages=Invoke-RestMethod -Uri ('http://127.0.0.1:'+$debugPort+'/json/list') -TimeoutSec 5
$page=$pages | Where-Object {$_.type -eq 'page'} | Select-Object -First 1
$socket864=[Net.WebSockets.ClientWebSocket]::new()
$socket864.ConnectAsync([uri]$page.webSocketDebuggerUrl,[Threading.CancellationToken]::None).GetAwaiter().GetResult() | Out-Null
$script:sequence864=0
function Send-Cdp864([string]$method,$parameters){
 $script:sequence864++;$sequence=$script:sequence864
 $payload=@{id=$sequence;method=$method;params=$parameters} | ConvertTo-Json -Depth 20 -Compress
 $bytes=[Text.Encoding]::UTF8.GetBytes($payload)
 $socket864.SendAsync([ArraySegment[byte]]::new($bytes),[Net.WebSockets.WebSocketMessageType]::Text,$true,[Threading.CancellationToken]::None).GetAwaiter().GetResult() | Out-Null
 while($true){
  $stream=[IO.MemoryStream]::new();$buffer=New-Object byte[] 65536
  do{$received=$socket864.ReceiveAsync([ArraySegment[byte]]::new($buffer),[Threading.CancellationToken]::None).GetAwaiter().GetResult();$stream.Write($buffer,0,$received.Count)}while(-not $received.EndOfMessage)
  $message=[Text.Encoding]::UTF8.GetString($stream.ToArray()) | ConvertFrom-Json;$stream.Dispose()
  if($message.id -eq $sequence){if($message.error){throw ($message.error | ConvertTo-Json -Compress)};return $message}
 }
}
$serverProcess=$null
try{
 $portFile=Join-Path $Root ('http-port-'+[guid]::NewGuid().ToString('N')+'.txt')
 # Repository root supplied explicitly by release runner.
 $serverProcess=Start-Process -FilePath powershell.exe -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',(Join-Path $Root 'local-server.ps1'),'-RepoRoot',$repoRoot,'-PortFile',$portFile) -WindowStyle Hidden -PassThru -RedirectStandardError (Join-Path $Root 'http-server-errors.txt')
 for($attempt=0;$attempt -lt 50 -and -not(Test-Path $portFile);$attempt++){Start-Sleep -Milliseconds 100}
 if(-not(Test-Path $portFile)){throw 'Local read-only server unavailable'}
 $port=[IO.File]::ReadAllText($portFile);$base='http://127.0.0.1:'+$port+'/Epi-Center/'
 Send-Cdp864 'Emulation.setDeviceMetricsOverride' @{width=390;height=844;deviceScaleFactor=1;mobile=$true} | Out-Null
 Send-Cdp864 'Page.enable' @{} | Out-Null
 Send-Cdp864 'Page.addScriptToEvaluateOnNewDocument' @{source="window.rootErrors865=[];window.addEventListener('error',e=>rootErrors865.push(e.message));"} | Out-Null
 function Navigate-Root865([string]$url){
  Send-Cdp864 'Page.navigate' @{url=$url} | Out-Null
  for($i=0;$i -lt 100;$i++){
   Start-Sleep -Milliseconds 100
   $expectedUrl=$url | ConvertTo-Json -Compress
   try{$ready=Send-Cdp864 'Runtime.evaluate' @{expression="location.href===$expectedUrl&&document.readyState==='complete'&&typeof appearanceUI864==='object'&&Array.isArray(window.rootErrors865)&&document.title.includes('v0.8.67')";returnByValue=$true}}catch{if($_.Exception.Message -match 'navigated|context|closed'){continue};throw}
   if($ready.result.result.value){return}
  }
  $diag=Send-Cdp864 'Runtime.evaluate' @{expression="JSON.stringify({url:location.href,title:document.title,errors:window.rootErrors865,text:document.body.innerText.slice(0,700)})";returnByValue=$true}; throw ($diag | ConvertTo-Json -Depth 6)
 }
 $candidate=$base+'epi-center-v0.8.67-reusable-autonomy-foundation.html'
 Navigate-Root865 $candidate
 function Eval866([string]$js){
  $r=Send-Cdp864 'Runtime.evaluate' @{expression=$js;returnByValue=$true}
  if($r.result.exceptionDetails){throw ($r.result.exceptionDetails | ConvertTo-Json -Depth 7)}
  return $r.result.result.value
 }

 Eval866 @"
document.getElementById('name').value='Persistent Autonomy Tester';start({preventDefault(){}});
document.getElementById('prof_age').value='34';document.getElementById('prof_gender').value='Male';document.getElementById('prof_hands').value='Authored original hands';saveProfile({preventDefault(){}});
Object.assign(h63(),{influence:100,mastered:false,stage:5,worn:false});anatomyInit65().index=STEPS65.length;s.activeForm='Erin';s.location='erinhome';s.screen='play69';Object.assign(erin817(),{clock:18,minute:0,day:1,trust:57,stress:15});roomState835().room='living';Object.assign(ui838(),{room:'living',view:'room',object:''});Object.assign(livingState840(),{bookProgress:0,bookReadCount:0,tv:'fireplace'});advance818(5);save();
sessionStorage.setItem('persistExpected867',JSON.stringify({autonomy:s.autonomy867,clock:clockMinute867(),archive:s.original06,profile:s.originalAppearance864,inventory:s.inventory,quest:s.quest,questDone:s.questDone,gold:s.gold,exp:s.exp,attributes:s.stats,trust:erin817().trust,influence:h63().influence,anatomy:anatomyInit65()}));sessionStorage.setItem('persistResults867','[]');
"@ | Out-Null
 Navigate-Root865 $candidate
 $j=Eval866 @"
(function(){const e=JSON.parse(sessionStorage.getItem('persistExpected867')),r=JSON.parse(sessionStorage.getItem('persistResults867'));const check=(name,pass)=>{r.push({name,pass:!!pass});if(!pass)throw Error(name);};
check('Actual reload preserves pending duration, cooldowns, needs and history',JSON.stringify(s.autonomy867)===JSON.stringify(e.autonomy));
check('Reload does not advance the authoritative clock',clockMinute867()===e.clock);
check('Reload preserves original appearance archives',JSON.stringify(s.original06)===JSON.stringify(e.archive)&&JSON.stringify(s.originalAppearance864)===JSON.stringify(e.profile)&&baseline67('hands')==='Authored original hands');
check('Reload preserves inventory, quest and attribute progress',JSON.stringify(s.inventory)===JSON.stringify(e.inventory)&&s.quest===e.quest&&s.questDone===e.questDone&&s.gold===e.gold&&s.exp===e.exp&&JSON.stringify(s.stats)===JSON.stringify(e.attributes));
check('Reload preserves trust, influence and physical transformation',erin817().trust===e.trust&&h63().influence===e.influence&&JSON.stringify(anatomyInit65())===JSON.stringify(e.anatomy));
advance818(10);
check('Pending action completes once after remaining game duration',livingState840().bookProgress===1&&s.autonomy867.actors['erin-form'].history.length===1&&s.autonomy867.actors['erin-form'].pending===null);
sessionStorage.setItem('persistAfter867',JSON.stringify(s.autonomy867));sessionStorage.setItem('persistResults867',JSON.stringify(r));save();return true;})();
"@
 Navigate-Root865 $candidate
 Eval866 @"
(function(){const r=JSON.parse(sessionStorage.getItem('persistResults867'));const pass=JSON.stringify(s.autonomy867)===sessionStorage.getItem('persistAfter867')&&livingState840().bookProgress===1&&rootErrors865.length===0;r.push({name:'Completed action and memory survive reload without replay',pass});if(!pass)throw Error('Completion replay');tick817(15);r.push({name:'Cooldown survives reload and blocks duplicate reading',pass:livingState840().bookProgress===1&&s.autonomy867.actors['erin-form'].history.length===1});sessionStorage.setItem('persistResults867',JSON.stringify(r));
Object.assign(erin817(),{day:2,clock:22,minute:0});roomState835().room='bedroom';Object.assign(ui838(),{room:'bedroom',view:'room',object:''});advance818(5);advance818(5);if(!s.autonomy867.actors['erin-form'].sleeping)throw Error('Sleep fixture failed');save();sessionStorage.setItem('sleepExpected867',JSON.stringify(s.autonomy867));return true;})();
"@ | Out-Null
 Navigate-Root865 $candidate
 $j=Eval866 @"
(function(){const r=JSON.parse(sessionStorage.getItem('persistResults867'));const pass=JSON.stringify(s.autonomy867)===sessionStorage.getItem('sleepExpected867')&&s.autonomy867.actors['erin-form'].sleeping&&roomState835().room==='bedroom';r.push({name:'Sleep state, posture and schedule survive actual reload',pass});if(!pass)throw Error('Sleep reload');
advance818(540);advance818(1);r.push({name:'Persistent sleep wakes through subsequent game time',pass:!s.autonomy867.actors['erin-form'].sleeping&&s.erin828.bedtimeStage===0});
const journal=document.createElement('div');journal.innerHTML=autonomyJournal867();r.push({name:'Journal includes actor timestamp location action outcome and effects',pass:journal.textContent.includes('Erin')&&journal.textContent.includes('Day ')&&journal.textContent.includes('bedroom')&&journal.textContent.includes('completed')&&journal.textContent.includes('actor.sleeping')});
r.push({name:'No browser errors after persistence tests',pass:rootErrors865.length===0});return JSON.stringify({results:r,passed:r.filter(x=>x.pass).length,total:r.length});})();
"@
 [IO.File]::WriteAllText((Join-Path $Root 'persistence-results.json'),$j)
 $d=$j | ConvertFrom-Json; 'Persistence checks: '+$d.passed+'/'+$d.total
}finally{
 if($socket864.State -eq [Net.WebSockets.WebSocketState]::Open){try{Send-Cdp864 'Browser.close' @{} | Out-Null}catch{}}
 $socket864.Dispose();if($serverProcess -and -not $serverProcess.HasExited){Stop-Process -Id $serverProcess.Id}
}
