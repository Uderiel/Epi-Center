
(()=>{
const r=[],examples={},check=(name,pass)=>{r.push({name,pass:!!pass});if(!pass)throw Error(name);};
document.getElementById('name').value='Contextual Movement Tester';start({preventDefault(){}});
document.getElementById('prof_age').value='31';document.getElementById('prof_gender').value='Male';document.getElementById('prof_hands').value='Context original hands';saveProfile({preventDefault(){}});
function setup({fatigue=0,trust=57,stress=0,hour=4,minute=27,room='bedroom',intent='sleep'}={}){
 s.location='erinhome';s.screen='play69';s.activeForm='Erin';Object.assign(h63(),{stage:5,influence:100,worn:false,mastered:false});anatomyInit65().index=STEPS65.length;
 Object.assign(erin817(),{day:21,clock:hour,minute,trust,stress});roomState835().room=room;Object.assign(ui838(),{room,view:'room',object:''});s.autonomy867={schema:1,actors:{}};s.dialogue867={schema:1,actors:{}};s.sleep867=null;s.travel88.pending=null;autonomyEngine867=null;home848().awaiting=[];
 Object.assign(livingState840(),{bookProgress:0,bookReadCount:0,tv:'fireplace',lamp:false});s.console814.channel='form';const a=autonomy867().state(ERIN_AUTONOMY867,clockMinute867());a.needs.fatigue=fatigue;if(intent)a.intention={actionId:intent,at:clockMinute867(),band:'maximum',reason:'disposable fixture intention'};render();s.live815.items=[];return a;
}
function send(text){render();document.getElementById('universal814').value=text;send816({preventDefault(){}});return s.live815.items.filter(e=>e.who.startsWith('Erin · private · ')).at(-1)?.text;}
let a=setup({fatigue:80}),begin=clockMinute867();
for(let i=0;i<9;i++){const b=Array.from(document.querySelectorAll('button')).find(b=>b.getAttribute('onclick')==="moveRoom835('hall')");check('Tired owner sequence has Hall control '+i,!!b);b.click();check('Tired owner sequence preserves physical/UI Bedroom '+i,roomState835().room==='bedroom'&&ui838().room==='bedroom');}
check('Exact tired sequence reaches Day 21 04:36',clockMinute867()===begin+9&&erin817().day===21&&erin817().clock===4&&erin817().minute===36);
check('No repeated fake return-to-bed completions',!a.history.some(e=>e.action==='move-to-bed'&&e.outcome==='completed'));
check('Refusals reflect tiredness and are visible',a.history.filter(e=>e.outcome==='blocked').length===9&&s.live815.items.some(e=>/needs rest/.test(e.text)));
check('No false Hall entry in tired sequence',!s.live815.items.some(e=>e.text==='You enter the Entry Hall.'));
examples.tiredRefusal=s.live815.items.find(e=>e.who==='Erin · private')?.text;
examples.activityPreference=send('What would you like to do?');
examples.lunchPreference=send('What would you like for lunch?');
check('Natural questions retain non-action outcomes',dialogueState867().lastOutcome.outcome==='conversation'&&!dialogueState867().pending);
a=setup({fatigue:0,trust:57,stress:0});check('Rested same-time decision permits accommodation',movementAuthority868('hall').allowed);moveRoom835('hall');
check('Rested same-time physical move actually reaches Hall',roomState835().room==='hall'&&ui838().room==='hall');
check('Accommodation is bounded and scoped, not a global pause',a.movementAgreement868.destination==='hall'&&a.movementAgreement868.until>clockMinute867()&&!a.pauseUntil);
examples.cooperativeMove=s.live815.items.find(e=>/accommodates the move/.test(e.text))?.text;
actionMinute836(1);check('Next scheduler step does not undo accommodated move',roomState835().room==='hall'&&!a.history.some(e=>e.action==='move-to-bed'&&e.outcome==='completed'));
a.needs.fatigue=80;actionMinute836(15);check('Other actual autonomy remains active during accommodation',a.history.some(e=>e.action==='rest'&&e.outcome==='completed')&&a.needs.fatigue<80&&roomState835().room==='hall');
examples.independentRest=s.live815.items.find(e=>e.who==='World · Erin'&&/rest/.test(e.text))?.text;
actionMinute836(15);actionMinute836(1);check('After the bounded agreement expires Erin may resume her routine',clockMinute867()>a.movementAgreement868.until&&roomState835().room==='bedroom');
a=setup({fatigue:0,trust:5,stress:0});moveRoom835('hall');check('Low trust can refuse same rested movement',roomState835().room==='bedroom'&&!a.movementAgreement868);
a=setup({fatigue:0,trust:95,stress:70});const strained=movementAuthority868('hall');check('Stress changes cooperation despite high trust',!strained.allowed&&strained.negotiate868);moveRoom835('hall');examples.negotiation=s.live815.items.find(e=>e.who==='Erin · private')?.text;
a=setup({fatigue:0,trust:95,stress:0});moveRoom835('hall');check('High trust with low stress can accommodate same movement',roomState835().room==='hall');
a=setup({fatigue:0,trust:95});a.sleeping=true;check('Actual sleeping state is protected despite high cooperation',!movementAuthority868('hall').allowed);
a=setup({fatigue:0,trust:95});actionMinute836(1);check('A real pending sleep commitment matters, not time alone',a.pending?.action==='prepare-sleep'&&!movementAuthority868('hall').allowed);
a=setup({fatigue:0,trust:95,intent:'read'});moveRoom835('hall');actionMinute836(1);check('Permitted movement consistent with another intention is not instantly reversed',roomState835().room==='hall'&&a.movementAgreement868);
a=setup({fatigue:0,trust:95});ERIN_AUTONOMY867.movementPolicy868={accommodateRested:false};check('Character policy can change willingness without new dice',!movementAuthority868('hall').allowed);delete ERIN_AUTONOMY867.movementPolicy868;
a=setup({hour:18,minute:0,room:'living',fatigue:0,trust:5,intent:'read'});actionMinute836(5);check('Guarded form may protect an actual reading commitment',a.pending?.action==='read'&&!movementAuthority868('hall').allowed);
a=setup({hour:18,minute:0,room:'living',fatigue:0,trust:95,intent:'read'});actionMinute836(5);moveRoom835('hall');actionMinute836(1);check('Cooperative reading interruption is accommodated without immediate return to Living Room',roomState835().room==='hall'&&a.movementAgreement868.from==='living');
a=setup({fatigue:80,trust:95});moveRoom835('hall');examples.pauseAnswer=send('Could you pause please?');check('Existing dialogue rules can agree to a pause despite fatigue',dialogueState867().pending.outcome==='agree');authorizeDialogue867();moveRoom835('hall');actionMinute836(5);
check('Successful negotiated pause is not immediately undone',roomState835().room==='hall'&&a.pauseUntil>clockMinute867()&&a.intention);
check('Negotiation did not alter influence trust or stress',h63().influence===100&&erin817().trust===95&&erin817().stress===0);
a=setup({fatigue:80});h63().owned=true;h63().worn=true;items850();check('Resisted fixture starts with a genuine refusal',!movementAuthority868('hall').allowed);
const originalRoll=heelCheck63,calls=[];heelCheck63=(stat,dc)=>{calls.push({stat,dc});return true;};resistHeels63();resistHeels63();heelCheck63=originalRoll;moveRoom835('hall');actionMinute836(5);
check('Existing resistance result retains its normal numeric effect',h63().influence===74&&calls.length===2&&calls[0].dc===17&&calls[1].dc===16);
check('Successful resistance movement is not immediately undone',roomState835().room==='hall'&&!a.history.some(e=>e.action==='move-to-bed'&&e.outcome==='completed'));
check('No cursed removal or transformation reversal was invented',h63().worn&&anatomyInit65().index===STEPS65.length);
a=setup({hour:18,minute:0,fatigue:0,trust:57,intent:'read'});moveRoom835('hall');actionMinute836(1);check('Ordinary daytime autonomy still continues when no agreement protects an opposing move',roomState835().room==='living'&&a.history.some(e=>e.action==='move-to-living'&&e.outcome==='completed'));
a=setup({fatigue:0,trust:57});moveRoom835('hall');actionMinute836(1);save();
sessionStorage.setItem('context868-results',JSON.stringify(r));sessionStorage.setItem('context868-examples',JSON.stringify(examples));sessionStorage.setItem('context868-expected',JSON.stringify({actor:s.autonomy867,clock:clockMinute867(),room:roomState835().room,original:s.original06}));return JSON.stringify(r);
})();
