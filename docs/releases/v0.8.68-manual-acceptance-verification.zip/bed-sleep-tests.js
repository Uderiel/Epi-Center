﻿
(()=>{
const results=[],check=(name,pass)=>{results.push({name,pass:!!pass});if(!pass)throw Error(name);};
document.getElementById('name').value='Bed Sleep Tester';start({preventDefault(){}});
document.getElementById('prof_age').value='31';document.getElementById('prof_gender').value='Male';saveProfile({preventDefault(){}});
Object.assign(h63(),{stage:5,influence:100,mastered:false,worn:false});anatomyInit65().index=STEPS65.length;s.activeForm='Erin';s.location='erinhome';s.screen='play69';roomState835().room='bedroom';Object.assign(erin817(),{day:1,clock:23,minute:30});homeOpen848('bed');
const engine=autonomy867(),actor=engine.state(ERIN_AUTONOMY867,clockMinute867());actor.needs.fatigue=80;actor.pending={id:'fixture-pending',action:'read',started:clockMinute867(),due:clockMinute867()+15,location:'erinhome',room:'living'};
const snapshot=JSON.stringify({inventory:s.inventory,objects:items850().objects,original:s.original06,stats:s.stats,trust:erin817().trust,influence:h63().influence,quest:s.quest,gold:s.gold,exp:s.exp,anatomy:anatomyInit65()});
check('Full sleep option visible alongside existing rests',!!document.querySelector('button[onclick="sleepAtBed867()"]')&&document.body.innerText.includes('Sit and relax')&&document.body.innerText.includes('Lie down for a while'));
const before=clockMinute867();document.querySelector('button[onclick="sleepAtBed867()"]').click();
check('Full cycle advances exactly 480 shared-clock minutes',clockMinute867()===before+480&&erin817().day===2&&erin817().clock===7&&erin817().minute===30);
check('Player wakes at bedroom with sleeping flags clear',!s.sleep867.active&&!actor.sleeping&&!actor.readyForSleep&&roomState835().room==='bedroom'&&s.location==='erinhome');
check('Full sleep clears fatigue using existing configured sleep rate',actor.needs.fatigue===0);
check('Previous pending action cancelled without stale reading',actor.pending===null&&actor.history.some(e=>e.id==='fixture-pending'&&e.outcome==='cancelled'));
check('No unrelated equipment, identity, transformation or progression changes',snapshot===JSON.stringify({inventory:s.inventory,objects:items850().objects,original:s.original06,stats:s.stats,trust:erin817().trust,influence:h63().influence,quest:s.quest,gold:s.gold,exp:s.exp,anatomy:anatomyInit65()}));
check('Manual sleep journal entry records one full cycle',s.sleep867.history.length===1&&s.sleep867.history[0].action==='full-sleep-cycle'&&autonomyJournal867().includes('full-sleep-cycle'));
check('Bed reports actual completion time',document.body.innerText.includes('Last full sleep completed: Day 2'));
check('Sleep UI fits Android width',document.documentElement.scrollWidth<=innerWidth);
ui838().object='dresser';const noSleepTime=clockMinute867();sleepAtBed867();check('Sleep rejected away from bed',clockMinute867()===noSleepTime);homeOpen848('bed');
s.travel88.pending={to:'hub'};sleepAtBed867();check('Pending travel blocks sleep',clockMinute867()===noSleepTime);s.travel88.pending=null;
h63().influence=20;s.sleep867={active:true,started:clockMinute867()-120,due:clockMinute867()+360,location:'erinhome',room:'bedroom',history:s.sleep867.history};save();
sessionStorage.setItem('sleepChecks',JSON.stringify(results));sessionStorage.setItem('resumeClock',String(clockMinute867()));return JSON.stringify(results);
})();
