﻿param([string]$RepoRoot,[string]$PortFile)
$allowed=@{'index.html'=$true;'epi-center-v0.8.64-character-creation-field-cleanup.html'=$true;'epi-center-v0.8.68-manual-acceptance-repairs.html'=$true;'epi-center-v0.8.67-reusable-autonomy-foundation.html'=$true;'epi-center-v0.8.66-jewelry-storage-and-build-display.html'=$true;'epi-center-v0.8.65-red-heels-acquisition-fix.html'=$true}
$listener=[Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,0)
$listener.Start()
[IO.File]::WriteAllText($PortFile,[string]$listener.LocalEndpoint.Port)
try{while($true){
 $client=$listener.AcceptTcpClient()
 try{
  $stream=$client.GetStream();$reader=[IO.StreamReader]::new($stream,[Text.Encoding]::ASCII,$false,4096,$true)
  $first=$reader.ReadLine();if(-not $first){continue};while($reader.ReadLine()){}
  $parts=$first.Split(' ');$path=([uri]('http://localhost'+$parts[1])).AbsolutePath
  if($path.StartsWith('/Epi-Center/')){$path=$path.Substring(12)}else{$path=$path.TrimStart('/')}
  if(-not $path){$path='index.html'}
  if($allowed.ContainsKey($path)){$bytes=[IO.File]::ReadAllBytes((Join-Path $RepoRoot $path));$status='200 OK'}else{$bytes=[Text.Encoding]::UTF8.GetBytes('Not found');$status='404 Not Found'}
  $header=[Text.Encoding]::ASCII.GetBytes("HTTP/1.1 $status`r`nContent-Type: text/html; charset=utf-8`r`nContent-Length: $($bytes.Length)`r`nCache-Control: no-store`r`nConnection: close`r`n`r`n")
  $stream.Write($header,0,$header.Length);if($parts[0] -ne 'HEAD'){$stream.Write($bytes,0,$bytes.Length)};$stream.Flush();$reader.Dispose()
 }catch{}finally{$client.Dispose()}
}}finally{$listener.Stop()}
