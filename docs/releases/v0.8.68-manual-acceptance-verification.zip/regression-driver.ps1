﻿param([string]$Root,[Parameter(Mandatory=$true)][string]$RepoRoot)
$profile=Join-Path $Root ('device-profile-'+[guid]::NewGuid().ToString('N'))
$browser=Start-Process -FilePath 'C:/Program Files/Google/Chrome/Application/chrome.exe' -ArgumentList @('--headless=new','--disable-gpu','--no-first-run','--no-default-browser-check','--disable-background-networking','--remote-debugging-port=0',('--user-data-dir="'+$profile+'"'),'about:blank') -WindowStyle Hidden -PassThru -RedirectStandardError (Join-Path $Root 'device-driver-errors.txt')
$portFile=Join-Path $profile 'DevToolsActivePort'
for($attempt=0;$attempt -lt 50 -and -not(Test-Path -LiteralPath $portFile);$attempt++){Start-Sleep -Milliseconds 100}
if(-not(Test-Path -LiteralPath $portFile)){throw 'Disposable Chrome debugging endpoint unavailable'}
$debugPort=[IO.File]::ReadAllLines($portFile)[0]
$pages=Invoke-RestMethod -Uri ('http://127.0.0.1:'+$debugPort+'/json/list') -TimeoutSec 5
$page=$pages | Where-Object {$_.type -eq 'page'} | Select-Object -First 1
$socket864=[Net.WebSockets.ClientWebSocket]::new()
$socket864.ConnectAsync([uri]$page.webSocketDebuggerUrl,[Threading.CancellationToken]::None).GetAwaiter().GetResult() | Out-Null
$script:sequence864=0
function Send-Cdp864([string]$method,$parameters){
 $script:sequence864++;$sequence=$script:sequence864
 $payload=@{id=$sequence;method=$method;params=$parameters} | ConvertTo-Json -Depth 20 -Compress
 $bytes=[Text.Encoding]::UTF8.GetBytes($payload)
 $socket864.SendAsync([ArraySegment[byte]]::new($bytes),[Net.WebSockets.WebSocketMessageType]::Text,$true,[Threading.CancellationToken]::None).GetAwaiter().GetResult() | Out-Null
 while($true){
  $stream=[IO.MemoryStream]::new();$buffer=New-Object byte[] 65536
  do{$received=$socket864.ReceiveAsync([ArraySegment[byte]]::new($buffer),[Threading.CancellationToken]::None).GetAwaiter().GetResult();$stream.Write($buffer,0,$received.Count)}while(-not $received.EndOfMessage)
  $message=[Text.Encoding]::UTF8.GetString($stream.ToArray()) | ConvertFrom-Json;$stream.Dispose()
  if($message.id -eq $sequence){if($message.error){throw ($message.error | ConvertTo-Json -Compress)};return $message}
 }
}
$serverProcess=$null
try{
 $portFile=Join-Path $Root ('http-port-'+[guid]::NewGuid().ToString('N')+'.txt')
 # Repository root supplied explicitly by release runner.
 $serverProcess=Start-Process -FilePath powershell.exe -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',(Join-Path $Root 'local-server.ps1'),'-RepoRoot',$repoRoot,'-PortFile',$portFile) -WindowStyle Hidden -PassThru -RedirectStandardError (Join-Path $Root 'http-server-errors.txt')
 for($attempt=0;$attempt -lt 50 -and -not(Test-Path $portFile);$attempt++){Start-Sleep -Milliseconds 100}
 if(-not(Test-Path $portFile)){throw 'Local read-only server unavailable'}
 $port=[IO.File]::ReadAllText($portFile);$base='http://127.0.0.1:'+$port+'/Epi-Center/'
 Send-Cdp864 'Emulation.setDeviceMetricsOverride' @{width=390;height=844;deviceScaleFactor=1;mobile=$true} | Out-Null
 Send-Cdp864 'Page.enable' @{} | Out-Null
 Send-Cdp864 'Page.addScriptToEvaluateOnNewDocument' @{source="window.rootErrors865=[];window.addEventListener('error',e=>rootErrors865.push(e.message));"} | Out-Null
 function Navigate-Root865([string]$url){
  Send-Cdp864 'Page.navigate' @{url=$url} | Out-Null
  for($i=0;$i -lt 100;$i++){
   Start-Sleep -Milliseconds 100
   $expectedUrl=$url | ConvertTo-Json -Compress
   try{$ready=Send-Cdp864 'Runtime.evaluate' @{expression="location.href===$expectedUrl&&document.readyState==='complete'&&typeof appearanceUI864==='object'&&Array.isArray(window.rootErrors865)&&document.title.includes('v0.8.68')";returnByValue=$true}}catch{if($_.Exception.Message -match 'navigated|context|closed'){continue};throw}
   if($ready.result.result.value){return}
  }
  throw 'Game did not load from root/versioned HTTP entry'
 }
 Navigate-Root865 ($base+'epi-center-v0.8.68-manual-acceptance-repairs.html')
 $initial=@'
(function(){const results=[];function check(name,ok){results.push({name,pass:!!ok});if(!ok)throw new Error(name);}
check('HTTP root loads approved v0.8.65',document.title.includes('Manual Acceptance Repairs')&&!!document.getElementById('name'));
check('Main entry inline JavaScript compiles',Array.from(document.scripts).every(script=>{if(!script.src)new Function(script.textContent);return true;}));
check('Root is standalone without the old app.js entry script',!Array.from(document.scripts).some(x=>x.src.includes('app.js')));
check('Original 19-region specification and save key are available',APPEARANCE_FIELDS864.length===19&&FOUNDATION_KEY==='epicenter_foundation_v060');
document.getElementById('name').value='Root Compatibility Tester';start({preventDefault(){}});document.getElementById('prof_age').value='31';document.getElementById('prof_gender').value='Male';document.getElementById('prof_hands').value='Root original hand description';saveProfile({preventDefault(){}});
check('Root character creation saves the authored baseline',s.profileComplete&&baseline67('hands')==='Root original hand description');
statAdjust('Strength',1);setScreen('play69');survey06();survey06();survey06();enter('plaza');
check('Root scouting and connected travel work',s.location==='plaza'&&s.world06.discovered.includes('tunnel'));
survey06();survey06();enter('courtyard');const take=Array.from(document.querySelectorAll('button')).find(button=>button.getAttribute('onclick')?.includes('takeHeels63(')&&!button.disabled);check('Approved main entry exposes and completes normal red-heels acquisition',!!take);take.click();check('Main entry keeps one carried signature pair without auto-wearing '+JSON.stringify({owned:h63().owned,worn:h63().worn,inventory:s.inventory,location:redHeelsLocation865()}),h63().owned&&!h63().worn&&s.inventory['Erin\u2019s Red Heels']===1&&redHeelsLocation865()==='inventory');
s.inventory['Disposable compatibility marker']=1;save();
const expected={name:s.name,profile:s.original06,stats:s.stats,inventory:s.inventory,location:s.location,discovered:s.world06.discovered,gold:s.gold,exp:s.exp,anatomy:anatomyInit65()};sessionStorage.setItem('rootExpected865',JSON.stringify(expected));sessionStorage.setItem('rootResults865',JSON.stringify(results));return JSON.stringify(results);})();
'@
 $first=Send-Cdp864 'Runtime.evaluate' @{expression=$initial;returnByValue=$true}
 if($first.result.exceptionDetails){throw ($first.result.exceptionDetails | ConvertTo-Json -Depth 6)}
 Navigate-Root865 ($base+'epi-center-v0.8.68-manual-acceptance-repairs.html')
 $verify=@'
(function(){const results=JSON.parse(sessionStorage.getItem('rootResults865'));const expected=JSON.parse(sessionStorage.getItem('rootExpected865'));const actual={name:s.name,profile:s.original06,stats:s.stats,inventory:s.inventory,location:s.location,discovered:s.world06.discovered,gold:s.gold,exp:s.exp,anatomy:anatomyInit65()};const pass=JSON.stringify(expected)===JSON.stringify(actual);results.push({name:'Same-origin versioned build resumes the root save without resetting progress',pass});results.push({name:'Versioned HTTP page has no uncaught startup errors',pass:rootErrors865.length===0});sessionStorage.setItem('rootResults865',JSON.stringify(results));return JSON.stringify(results);})();
'@
 Send-Cdp864 'Runtime.evaluate' @{expression=$verify;returnByValue=$true} | Out-Null
 Navigate-Root865 ($base+'epi-center-v0.8.68-manual-acceptance-repairs.html')
 $last=@'
(function(){const results=JSON.parse(sessionStorage.getItem('rootResults865'));const expected=JSON.parse(sessionStorage.getItem('rootExpected865'));const actual={name:s.name,profile:s.original06,stats:s.stats,inventory:s.inventory,location:s.location,discovered:s.world06.discovered,gold:s.gold,exp:s.exp,anatomy:anatomyInit65()};results.push({name:'Returning to root index resumes the same foundation save',pass:JSON.stringify(expected)===JSON.stringify(actual)});results.push({name:'Root HTTP reload has no uncaught startup errors',pass:rootErrors865.length===0});return JSON.stringify({results,passed:results.filter(x=>x.pass).length,total:results.length,viewport:{width:innerWidth,height:innerHeight}});})();
'@
 $lastResult=Send-Cdp864 'Runtime.evaluate' @{expression=$last;returnByValue=$true}
 if($lastResult.result.exceptionDetails){throw ($lastResult.result.exceptionDetails | ConvertTo-Json -Depth 6)}
 $legacySeed=@'
(function(){const results=JSON.parse(sessionStorage.getItem('rootResults865'));const before={name:s.name,profile:s.original06,stats:s.stats,inventory:s.inventory,location:s.location,discovered:s.world06.discovered,gold:s.gold,exp:s.exp,anatomy:anatomyInit65()};const expected=JSON.parse(sessionStorage.getItem('rootExpected865'));results.push({name:'Returning to root index resumes the same foundation save',pass:JSON.stringify(before)===JSON.stringify(expected)});results.push({name:'Root HTTP reload has no uncaught startup errors',pass:rootErrors865.length===0});sessionStorage.setItem('rootResults865',JSON.stringify(results));localStorage.removeItem(FOUNDATION_KEY);localStorage.removeItem(KEY);localStorage.setItem('epicenter_proto_v1',JSON.stringify({name:'Legacy Root Tester',screen:'hub',location:'tunnel',gold:424,exp:17,level:1,quest:true,questDone:false,inventory:{'Basic Rations':5,'Escape Rope':2},chat:{},visited:['hub','tunnel'],activity:4}));return true;})();
'@
 Send-Cdp864 'Runtime.evaluate' @{expression=$legacySeed;returnByValue=$true} | Out-Null
 Navigate-Root865 ($base+'epi-center-v0.8.68-manual-acceptance-repairs.html')
 $legacyVerify=@'
(function(){const results=JSON.parse(sessionStorage.getItem('rootResults865'));results.push({name:'Representative old v0.4 root v1 save loads through the unchanged fallback without losing progress',pass:s.name==='Legacy Root Tester'&&s.gold===424&&s.exp===17&&s.quest&&!s.questDone&&s.location==='tunnel'&&s.inventory['Basic Rations']===5&&s.inventory['Escape Rope']===2&&s.visited.includes('tunnel')});const stored=JSON.parse(localStorage.getItem(FOUNDATION_KEY));results.push({name:'Migrated old root save persists in the existing foundation key',pass:FOUNDATION_KEY==='epicenter_foundation_v060'&&stored.name==='Legacy Root Tester'&&stored.gold===424&&rootErrors865.length===0});return JSON.stringify({results,passed:results.filter(x=>x.pass).length,total:results.length,viewport:{width:innerWidth,height:innerHeight}});})();
'@
 $legacyResult=Send-Cdp864 'Runtime.evaluate' @{expression=$legacyVerify;returnByValue=$true}
 if($legacyResult.result.exceptionDetails){throw ($legacyResult.result.exceptionDetails | ConvertTo-Json -Depth 6)}
 $json=$legacyResult.result.result.value;[IO.File]::WriteAllText((Join-Path $Root 'root-http-results.json'),$json)
 $report=$json | ConvertFrom-Json
 '{0}/{1} local HTTP root/save checks passed; viewport {2}x{3}' -f $report.passed,$report.total,$report.viewport.width,$report.viewport.height
 $report.results | Where-Object {-not $_.pass} | ConvertTo-Json -Depth 4
}finally{
 if($socket864.State -eq [Net.WebSockets.WebSocketState]::Open){try{Send-Cdp864 'Browser.close' @{} | Out-Null}catch{}}
 $socket864.Dispose();if($serverProcess -and -not $serverProcess.HasExited){Stop-Process -Id $serverProcess.Id}
}
