﻿param([Parameter(Mandatory=$true)][string]$RepoRoot,[string]$OutputRoot)
$ErrorActionPreference='Stop'
if(-not $OutputRoot){$OutputRoot=Join-Path $env:TEMP ('epi-center-release-867-'+[guid]::NewGuid().ToString('N'))}
New-Item -ItemType Directory -Path $OutputRoot -Force | Out-Null
Get-ChildItem -LiteralPath $PSScriptRoot -File | Where-Object {$_.Extension -in @('.ps1','.js')} | Copy-Item -Destination $OutputRoot
$suites='[["dialogue-driver.ps1","dialogue-results.json",60],["dialogue-persistence-driver.ps1","dialogue-persistence-results.json",9],["autonomy-driver.ps1","autonomy-results.json",61],["test-driver.ps1","fresh-results.json",249],["legacy-driver.ps1","legacy-results.json",52],["legacy866-driver.ps1","legacy-results.json",52],["persistence-driver.ps1","persistence-results.json",12],["bed-sleep-driver.ps1","bed-sleep-results.json",17],["regression-driver.ps1","root-http-results.json",14],["pending-driver.ps1","pending-results.json",38],["cursed-footwear-driver.ps1","cursed-footwear-results.json",22],["footwear-matrix-driver.ps1","footwear-matrix-results.json",21],["footwear-migration-driver.ps1","footwear-migration-results.json",9]]' | ConvertFrom-Json
$summary=@()
foreach($suite in $suites){
 Write-Output ('Suite: '+$suite[0])
 & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $OutputRoot $suite[0]) -Root $OutputRoot -RepoRoot $RepoRoot
 if($LASTEXITCODE -ne 0){throw ('Release blocker: '+$suite[0])}
 $raw=[IO.File]::ReadAllText((Join-Path $OutputRoot $suite[1]))
 $report=$raw|ConvertFrom-Json
 $results=if($raw.TrimStart().StartsWith('[')){@($report)}else{@($report.results)}
 if($results.Count -ne [int]$suite[2] -or @($results|Where-Object {-not $_.pass}).Count){throw ('Missing or failing checks: '+$suite[0])}
 [IO.File]::WriteAllText((Join-Path $OutputRoot ($suite[0]+'.results.json')),$raw)
 $summary+=@([pscustomobject]@{suite=$suite[0];passed=$results.Count;expected=[int]$suite[2]})
}
$summary|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $OutputRoot 'release-summary.json') -Encoding UTF8
$summary|Format-Table
Write-Output ('Results: '+$OutputRoot)
