﻿
(()=>{
const results=window.pendingResults=[],observations=window.pendingObservations=[];
const check=(name,pass,detail='')=>(window.lastPendingCheck=name,results.push({name,pass:!!pass,detail}));
const attempt=(name,fn)=>{try{window.lastScenario=name;console.log('SCENARIO: '+name);fn();}catch(e){check(name,false,e.message);}};
document.getElementById('name').value='Pending Coverage Tester';start({preventDefault(){}});
document.getElementById('prof_age').value='31';document.getElementById('prof_gender').value='Male';document.getElementById('prof_hands').value='Recorded original hands';saveProfile({preventDefault(){}});
const initial=JSON.stringify(s);
function reset(){
 for(const k of Object.keys(s))delete s[k];Object.assign(s,JSON.parse(initial));
 autonomyEngine867=null;appearanceUI864.edit=false;appearanceUI864.draft={};
 s.location='hub';s.screen='play69';s.activeForm='Original Human';Object.assign(h63(),{stage:0,influence:0,worn:false,mastered:false,owned:false});anatomyInit65().index=0;
 s.travel88.pending=null;save();render();
}
function full(){s.activeForm='Erin';h63().stage=5;anatomyInit65().index=STEPS65.length;}
function bedroom(){full();s.location='erinhome';roomState835().room='bedroom';homeOpen848('bed');}
attempt('Undiscovered route scenario',()=>{
 reset();s.world06.discovered=['hub','arcade'];s.visited=['hub'];const time=clockMinute867();enter('arcade');
 check('Known destination cannot cross undiscovered intermediate nodes',s.location==='hub'&&clockMinute867()===time&&!s.visited.includes('arcade'));
 s.travel88.pending={to:'arcade',feedback:''};travelRespond88('resist');
 check('Restored pending travel also respects undiscovered intermediate nodes',s.location==='hub'&&(!s.travel88.pending||s.travel88.pending.feedback.includes('No discovered connected route')));
});
attempt('Residence access scenario',()=>{
 reset();s.world06.discovered=['hub','courtyard820','erinhome'];s.visited=['hub','courtyard820'];s.location='courtyard820';residence829().guests=[];const time=clockMinute867();enter('erinhome');
 check('Original form without permission remains outside apartment',s.location==='courtyard820'&&clockMinute867()===time);
 full();enter('erinhome');check('Transformed resident can enter from discovered walkway',s.location==='erinhome'&&roomState835().room==='living');
});
attempt('Quest interface scenario',()=>{
 reset();setScreen('quests');const acceptButton=Array.from(document.querySelectorAll('button')).find(b=>(b.getAttribute('onclick')||'').includes('accept('));check('Starter quest acceptance accessible from Quests',!!acceptButton);if(acceptButton)acceptButton.click();else accept();
 const gold=s.gold,exp=s.exp;
 check('Accepting again does not grant completion rewards',(accept(),s.gold===gold&&s.exp===exp&&s.quest&&!s.questDone));
 completeFirstSteps863('tunnel');check('Quest cannot finish without tunnel visit',!s.questDone&&s.gold===gold);
 s.world06.discovered.push('tunnel');setScreen('play69');enter('tunnel');s.console814.channel='world';render();const originalComplete=completeFirstSteps863;let questDelta=null;completeFirstSteps863=function(at){const beforeGold=s.gold,beforeExp=s.exp,result=originalComplete(at);if(result)questDelta={gold:s.gold-beforeGold,exp:s.exp-beforeExp};return result;};document.getElementById('universal814').value='I inspect the tunnel walls.';send816({preventDefault(){}});
 completeFirstSteps863=originalComplete;check('World action in visited tunnel completes starter quest',s.questDone&&!s.quest&&questDelta?.gold===100&&questDelta?.exp===50);
 const rewarded={gold:s.gold,exp:s.exp};completeFirstSteps863('tunnel');accept();check('Completed quest rewards remain exactly once',s.gold===rewarded.gold&&s.exp===rewarded.exp);
});
attempt('Missing original details scenario',()=>{
 reset();setScreen('character');const anatomy=JSON.stringify(anatomyInit65()),hands=originalBaseline864().hands;
 openOriginalDetails864();check('Add Missing Original Details opens editable form',!!document.getElementById('prof_fingers'));
 document.getElementById('prof_fingers').value='Long original fingers';saveProfile({preventDefault(){}});
 check('Missing original detail recorded without rewriting existing description',originalBaseline864().fingers==='Long original fingers'&&originalBaseline864().hands===hands);
 check('Adding original details preserves transformation progress',JSON.stringify(anatomyInit65())===anatomy);
});
attempt('Laundry lifecycle scenario',()=>{
 reset();bedroom();const id='bra-ivory',x=items850().objects[id];
 itemAction850('carry',id);itemAction850('wear',id);itemAction850('unequip',id);
 check('Removed garment remains carried and marked worn',x.location==='inventory'&&x.condition==='worn');
 homeOpen848('hamper');itemAction850('deposit',id);check('Garment deposited in actual hamper',x.location==='hamper');
 laundryAction849('load');check('Hamper garment transfers to machine',x.location==='machine');
 laundryAction849('wash');check('Machine wash cleans the same garment',x.location==='machine'&&x.condition==='clean');
 laundryAction849('collect');check('Clean garment collected into inventory',x.location==='inventory'&&x.condition==='clean');
 itemAction850('return',id);check('Clean garment returns to original drawer once',x.location==='drawer3'&&CATALOG850.filter(d=>d.id===id).length===1);
});
attempt('Ordinary footwear exclusivity diagnostic',()=>{
 reset();bedroom();itemAction850('wear','shoes-4');itemAction850('wear','shoes-5');
 const worn=CATALOG850.filter(d=>d.slot==='shoes'&&items850().objects[d.id].location==='equipped').map(d=>d.id);
 check('Ordinary footwear replacement leaves one equipped pair',worn.length===1,'Equipped shoe IDs: '+worn.join(', '));
});
attempt('Cursed sleep and pickup scenario',()=>{
 reset();s.location='courtyard';takeHeels63();takeHeels63();
 check('Repeated courtyard pickup retains one unique pair',h63().owned&&s.inventory['Erin\u2019s Red Heels']===1);
 wearHeels63();s.location='erinhome';roomState835().room='bedroom';homeOpen848('bed');
 residence829().guests.push(String(s.name));const before=anatomyInit65().index,original=JSON.stringify(s.original06),time=clockMinute867();sleepAtBed867();
 check('Sleep while wearing cursed heels preserves equipped state',h63().worn&&items850().objects['shoes-0'].location==='equipped');
 check('Cursed sleep advances existing exposure without overwriting originals',clockMinute867()===time+480&&anatomyInit65().index>before&&JSON.stringify(s.original06)===original);
});
attempt('DEV acquired heels and storage scenario',()=>{
 reset();recoverErinHeels76();s.location='courtyard';const quantity=s.inventory['Erin\u2019s Red Heels'];takeHeels63();
 check('Debug-owned heels cannot be acquired a second time',quantity===1&&s.inventory['Erin\u2019s Red Heels']===1&&h63().owned);
 itemAction850('return','shoes-0');items850();check('Putting signature heels away preserves ownership in closet',items850().objects['shoes-0'].location==='closet-shoes'&&h63().owned);
});
attempt('Every influence-band observation',()=>{
 for(const influence of [0,25,50,75,100]){
  reset();bedroom();roomState835().room='living';Object.assign(erin817(),{clock:18,minute:0});h63().influence=influence;livingState840().bookProgress=0;livingState840().tv='fireplace';
  const reply=erinThought827('How are you feeling?');advance818(15);const a=autonomy867().store.actors['erin-form'];
  observations.push({influence,dialogueAvailable:!!reply,completedActions:a?.history.filter(e=>e.outcome==='completed').map(e=>e.action)||[],independentIntentionsRecorded:!!a?.intention});
  check('Form dialogue is available at influence '+influence,typeof reply==='string'&&reply.length>0);
 }
});
attempt('Automatic activity dependency guards',()=>{
 for(const id of ['work','meal','groom','cursed-footwear']){const action=ACTIONS867.find(a=>a.id===id);check(id+' is explicitly disabled, not falsely simulated',!!action?.disabled);}
});
attempt('Small screen controls and keyboard focus',()=>{
 reset();setScreen('character');openOriginalDetails864();document.querySelectorAll('details.original-region864').forEach(x=>x.open=true);
 const fingers=document.getElementById('prof_fingers');fingers.focus();check('Appearance input accepts focus at narrow viewport',document.activeElement===fingers);
 check('Expanded appearance form has no horizontal page overflow',document.documentElement.scrollWidth<=innerWidth);
 setScreen('play69');const composer=document.getElementById('universal814');composer.focus();check('Play action field accepts focus at narrow viewport',document.activeElement===composer);
 check('Play interface has no horizontal page overflow',document.documentElement.scrollWidth<=innerWidth);
});
check('No uncaught browser errors in supplemental scenarios',rootErrors865.length===0);
sessionStorage.setItem('supplementalResults',JSON.stringify({results,observations}));save();
return JSON.stringify({results,observations,passed:results.filter(x=>x.pass).length,total:results.length,viewport:{width:innerWidth,height:innerHeight}});
})();
