﻿param([string]$Root,[Parameter(Mandatory=$true)][string]$RepoRoot)
$profile=Join-Path $Root ('device-profile-'+[guid]::NewGuid().ToString('N'))
$browser=Start-Process -FilePath 'C:/Program Files/Google/Chrome/Application/chrome.exe' -ArgumentList @('--headless=new','--disable-gpu','--no-first-run','--no-default-browser-check','--disable-background-networking','--remote-debugging-port=0',('--user-data-dir="'+$profile+'"'),'about:blank') -WindowStyle Hidden -PassThru -RedirectStandardError (Join-Path $Root 'device-driver-errors.txt')
$portFile=Join-Path $profile 'DevToolsActivePort'
for($attempt=0;$attempt -lt 50 -and -not(Test-Path -LiteralPath $portFile);$attempt++){Start-Sleep -Milliseconds 100}
if(-not(Test-Path -LiteralPath $portFile)){throw 'Disposable Chrome debugging endpoint unavailable'}
$debugPort=[IO.File]::ReadAllLines($portFile)[0]
$pages=Invoke-RestMethod -Uri ('http://127.0.0.1:'+$debugPort+'/json/list') -TimeoutSec 5
$page=$pages | Where-Object {$_.type -eq 'page'} | Select-Object -First 1
$socket864=[Net.WebSockets.ClientWebSocket]::new()
$socket864.ConnectAsync([uri]$page.webSocketDebuggerUrl,[Threading.CancellationToken]::None).GetAwaiter().GetResult() | Out-Null
$script:sequence864=0
function Send-Cdp864([string]$method,$parameters){
 $script:sequence864++;$sequence=$script:sequence864
 $payload=@{id=$sequence;method=$method;params=$parameters} | ConvertTo-Json -Depth 20 -Compress
 $bytes=[Text.Encoding]::UTF8.GetBytes($payload)
 $socket864.SendAsync([ArraySegment[byte]]::new($bytes),[Net.WebSockets.WebSocketMessageType]::Text,$true,[Threading.CancellationToken]::None).GetAwaiter().GetResult() | Out-Null
 while($true){
  $stream=[IO.MemoryStream]::new();$buffer=New-Object byte[] 65536
  do{$received=$socket864.ReceiveAsync([ArraySegment[byte]]::new($buffer),[Threading.CancellationToken]::None).GetAwaiter().GetResult();$stream.Write($buffer,0,$received.Count)}while(-not $received.EndOfMessage)
  $message=[Text.Encoding]::UTF8.GetString($stream.ToArray()) | ConvertFrom-Json;$stream.Dispose()
  if($message.id -eq $sequence){if($message.error){throw ($message.error | ConvertTo-Json -Compress)};return $message}
 }
}
$serverProcess=$null
try{
 $portFile=Join-Path $Root ('http-port-'+[guid]::NewGuid().ToString('N')+'.txt')
 # Repository root supplied explicitly by release runner.
 $serverProcess=Start-Process -FilePath powershell.exe -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',(Join-Path $Root 'local-server.ps1'),'-RepoRoot',$repoRoot,'-PortFile',$portFile) -WindowStyle Hidden -PassThru -RedirectStandardError (Join-Path $Root 'http-server-errors.txt')
 for($attempt=0;$attempt -lt 50 -and -not(Test-Path $portFile);$attempt++){Start-Sleep -Milliseconds 100}
 if(-not(Test-Path $portFile)){throw 'Local read-only server unavailable'}
 $port=[IO.File]::ReadAllText($portFile);$base='http://127.0.0.1:'+$port+'/Epi-Center/'
 Send-Cdp864 'Emulation.setDeviceMetricsOverride' @{width=390;height=844;deviceScaleFactor=1;mobile=$true} | Out-Null
 Send-Cdp864 'Page.enable' @{} | Out-Null
 Send-Cdp864 'Page.addScriptToEvaluateOnNewDocument' @{source="window.rootErrors865=[];window.addEventListener('error',e=>rootErrors865.push(e.message));"} | Out-Null
 function Navigate-Root865([string]$url){
  Send-Cdp864 'Page.navigate' @{url=$url} | Out-Null
  for($i=0;$i -lt 100;$i++){
   Start-Sleep -Milliseconds 100
   $expectedUrl=$url | ConvertTo-Json -Compress
   try{$ready=Send-Cdp864 'Runtime.evaluate' @{expression="location.href===$expectedUrl&&document.readyState==='complete'&&typeof appearanceUI864==='object'&&Array.isArray(window.rootErrors865)&&document.title.includes('v0.8.68')";returnByValue=$true}}catch{if($_.Exception.Message -match 'navigated|context|closed'){continue};throw}
   if($ready.result.result.value){return}
  }
  $diag=Send-Cdp864 'Runtime.evaluate' @{expression="JSON.stringify({url:location.href,title:document.title,errors:window.rootErrors865,text:document.body.innerText.slice(0,700)})";returnByValue=$true}; throw ($diag | ConvertTo-Json -Depth 6)
 }
 $candidate=$base+'epi-center-v0.8.68-manual-acceptance-repairs.html'
 Navigate-Root865 $candidate
 function Eval866([string]$js){
  $r=Send-Cdp864 'Runtime.evaluate' @{expression=$js;returnByValue=$true}
  if($r.result.exceptionDetails){throw ($r.result.exceptionDetails | ConvertTo-Json -Depth 7)}
  return $r.result.result.value
 }

 Eval866 @"
document.getElementById('name').value='Dialogue Reload Tester';start({preventDefault(){}});
document.getElementById('prof_age').value='32';document.getElementById('prof_gender').value='Male';document.getElementById('prof_hands').value='Original reload hands';saveProfile({preventDefault(){}});
s.activeForm='Erin';h63().stage=5;h63().influence=20;h63().worn=false;h63().mastered=false;anatomyInit65().index=STEPS65.length;s.location='erinhome';s.screen='play69';roomState835().room='living';Object.assign(ui838(),{room:'living',view:'room',object:''});Object.assign(erin817(),{clock:18,minute:0,day:1,trust:90,stress:0});Object.assign(livingState840(),{bookProgress:0,bookReadCount:0,tv:'fireplace'});
s.console814.channel='form';render();document.getElementById('universal814').value='Could we read please?';send816({preventDefault(){}});Dialogue867.setInterpreter(()=>({intent:'request',actionId:'read'}));save();sessionStorage.setItem('dialogueReloadBefore',JSON.stringify({dialogue:s.dialogue867,clock:clockMinute867(),archive:s.original06,trust:erin817().trust,stress:erin817().stress,influence:h63().influence}));
"@ | Out-Null
 Navigate-Root865 $candidate
 Eval866 @"
(()=>{const r=[],e=JSON.parse(sessionStorage.getItem('dialogueReloadBefore')),check=(name,pass)=>{r.push({name,pass:!!pass});if(!pass)throw Error(name);};
check('Pending request and conversation memory survive real reload',JSON.stringify(s.dialogue867)===JSON.stringify(e.dialogue)&&dialogueState867().pending.outcome==='agree');
check('Reload does not execute agreement or advance time',clockMinute867()===e.clock&&livingState840().bookProgress===0);
check('Future interpreter callback is not serialized into saves',Dialogue867.interpret('hello').intent==='conversation');
check('Identity and distinct influence trust stress survive reload',JSON.stringify(s.original06)===JSON.stringify(e.archive)&&erin817().trust===e.trust&&erin817().stress===e.stress&&h63().influence===e.influence);
authorizeDialogue867();advance818(5);check('Reloaded agreement can authorize a pending action safely',!!autonomy867().store.actors['erin-form'].consent&&!!autonomy867().store.actors['erin-form'].pending&&livingState840().bookProgress===0);
sessionStorage.setItem('dialogueReloadResults',JSON.stringify(r));sessionStorage.setItem('dialogueDelegationBefore',JSON.stringify(s.autonomy867));save();})();
"@ | Out-Null
 Navigate-Root865 $candidate
 $j=Eval866 @"
(()=>{const r=JSON.parse(sessionStorage.getItem('dialogueReloadResults')),check=(name,pass)=>{r.push({name,pass:!!pass});if(!pass)throw Error(name);};
check('Consent and remaining duration survive actual reload',JSON.stringify(s.autonomy867)===sessionStorage.getItem('dialogueDelegationBefore'));
advance818(10);const a=autonomy867().store.actors['erin-form'];check('Delegated action completes exactly once after reload',livingState840().bookProgress===1&&a.history.filter(e=>e.action==='read'&&e.outcome==='completed').length===1&&!a.consent);
check('Original description remains archived',baseline67('hands')==='Original reload hands');
check('No browser errors during dialogue reloads',rootErrors865.length===0);
return JSON.stringify({results:r,passed:r.filter(x=>x.pass).length,total:r.length});})();
"@
 [IO.File]::WriteAllText((Join-Path $Root 'dialogue-persistence-results.json'),$j);$d=$j|ConvertFrom-Json;'Dialogue persistence checks: '+$d.passed+'/'+$d.total
}finally{
 if($socket864.State -eq [Net.WebSockets.WebSocketState]::Open){try{Send-Cdp864 'Browser.close' @{} | Out-Null}catch{}}
 $socket864.Dispose();if($serverProcess -and -not $serverProcess.HasExited){Stop-Process -Id $serverProcess.Id}
}
