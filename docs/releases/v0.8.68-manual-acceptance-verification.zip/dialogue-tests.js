﻿
(()=>{
const r=[],check=(name,pass)=>{r.push({name,pass:!!pass});if(!pass)throw Error(name);};
document.getElementById('name').value='Dialogue Band Tester';start({preventDefault(){}});
document.getElementById('prof_age').value='31';document.getElementById('prof_gender').value='Male';saveProfile({preventDefault(){}});
function reset(influence=100,trust=90,stress=0){
 s.location='erinhome';s.screen='play69';s.activeForm='Erin';Object.assign(h63(),{stage:5,influence,mastered:false,worn:false});anatomyInit65().index=STEPS65.length;
 Object.assign(erin817(),{clock:18,minute:0,day:1,trust,stress});roomState835().room='living';Object.assign(ui838(),{room:'living',view:'room',object:''});Object.assign(livingState840(),{bookProgress:0,bookReadCount:0,tv:'fireplace',lamp:false,seat:''});
 s.dialogue867={schema:1,actors:{}};s.autonomy867={schema:1,actors:{}};s.sleep867=null;s.travel88.pending=null;autonomyEngine867=null;Dialogue867.setInterpreter(null);s.console814.channel='form';render();return autonomy867();
}
function send(text){render();document.getElementById('universal814').value=text;send816({preventDefault(){}});return dialogueState867().lastOutcome;}
check('All five band boundaries', [0,24,25,49,50,74,75,99,100].map(x=>influenceBand867(x).id).join(',')==='primary,primary,limited,limited,shared,shared,strong,strong,maximum');
for(const influence of [0,20,25,50,75,80,100]){
 const e=reset(influence);advance818(1);const a=e.store.actors['erin-form'];
 check('Private intentions at '+influence,!!a.intention&&a.intentions.length===1);
 check('Coarse needs remain active at '+influence,a.needs.fatigue>20);
 if(influence<25)check('Primary player control has no forced outward action at '+influence,a.history.length===0&&!livingState840().lamp);
 if(influence>=25&&influence<75)check('Limited/shared bands allow minor lamp behavior without significant reading at '+influence,livingState840().lamp&&livingState840().bookProgress===0);
 if(influence>=75){advance818(14);check('Strong/maximum bands execute permitted ordinary routines at '+influence,livingState840().bookProgress===1);}
}
reset(0);check('Negation is recognized',Dialogue867.interpret("Please don't read that book").intent==='avoid');
check('Plain not negation is recognized',Dialogue867.interpret('Can we not read?').intent==='avoid');
check('Why dont we idiom remains a suggestion',Dialogue867.interpret("Why don't we read?").intent==='request');
check('Compound action asks for clarification',Dialogue867.interpret('Could we read and sleep?').intent==='clarify');
check('Question is not an execution request',Dialogue867.interpret('Do you enjoy reading?').intent==='question');
check('Unbound yes needs clarification',Dialogue867.interpret('yes').intent==='clarify');
let e=reset(0);let answer=send('Could we read a chapter please?');
check('High trust agrees without executing request',answer.outcome==='agree'&&livingState840().bookProgress===0&&e.store.actors['erin-form'].pending===null);
const now=clockMinute867();authorizeDialogue867();check('Authorization itself does not perform or advance activity',clockMinute867()===now&&livingState840().bookProgress===0&&e.store.actors['erin-form'].consent.actionId==='read');
advance818(15);check('Player may explicitly delegate an agreed activity at low influence',livingState840().bookProgress===1&&!e.store.actors['erin-form'].consent);
reset(0);send('Could we read please?');authorizeDialogue867();advance818(5);send("Please don't read");advance818(15);check('Withdrawing delegation prevents stale low-influence action',livingState840().bookProgress===0&&!autonomy867().store.actors['erin-form'].consent);
reset(100,20,30);check('Low cooperation can refuse',send('Read the book').outcome==='refuse');
reset(100,5,90);check('High stress and low trust may leave a demand unanswered',send('I order you to read the book').outcome==='ignore');
reset(100,50,20);check('Intermediate cooperation negotiates',send('Could we read please?').outcome==='negotiate');
check('A respectful explanation can change negotiation to agreement',send('Please, because it would help us unwind.').outcome==='agree');
reset(100,90,0);s.travel88.pending={to:'hub'};check('Commitment delays a request',Dialogue867.assess(Dialogue867.interpret('Could we read please?')).outcome==='delay');s.travel88.pending=null;
reset(100);erin817().clock=10;check('Reserved weekday schedule delays a leisure request',send('Could we read?').outcome==='delay');
reset(100);check('Unavailable meals propose an alternative without consumption',send('Could we prepare dinner?').outcome==='alternative'&&dialogueState867().pending.actionId==='meal');
reset(100);check('Negated request cannot be authorized',(send("Please don't read"),authorizeDialogue867(),!autonomy867().store.actors['erin-form'].consent));
reset(100);send('Could we read?');const oldBook=livingState840().bookProgress;livingState840().bookProgress=4;authorizeDialogue867();check('Changed prerequisites are rechecked at authorization',livingState840().bookProgress===4&&!autonomy867().store.actors['erin-form'].consent);
reset(100);send('Could we read?');const oldTrust=erin817().trust,oldStress=erin817().stress;check('Requests do not farm trust or confuse stress with influence',oldTrust===90&&oldStress===0&&h63().influence===100);
reset(80,5,90);livingState840().tv='off';send('I order you to read');advance818(10);check('Strong authority may choose a permitted alternative after refusing request',livingState840().bookProgress===0&&livingState840().tv==='fireplace');
e=reset(100);advance818(5);const pending=e.store.actors['erin-form'].pending?.id;send('How are you feeling?');check('Conversation preserves a current physical commitment without completing it',e.store.actors['erin-form'].pending?.id===pending&&livingState840().bookProgress===0);advance818(8);check('Pending commitment completes once through elapsed clock after conversation',livingState840().bookProgress===1);
reset(100);send('Could you pause please?');authorizeDialogue867();advance818(15);check('Agreed pause preserves intentions but suspends body routines',!!autonomy867().store.actors['erin-form'].intention&&livingState840().bookProgress===0);
reset(100);h63().mastered=true;advance818(15);check('Mastery preserves primary player control without silencing form',!!autonomy867().store.actors['erin-form'].intention&&livingState840().bookProgress===0);
reset(20);anatomyInit65().index=3;h63().worn=true;advance818(1);check('Incomplete worn animate form has thoughts without impossible body routine',!!autonomy867().store.actors['erin-form'].intention&&livingState840().bookProgress===0);
reset(20);s.location='hub';advance818(5);check('Form can want to go home without teleporting',autonomy867().store.actors['erin-form'].intention.actionId==='return-home'&&s.location==='hub');
check('AI proposal rejects arbitrary action',Dialogue867.validateProposal({intent:'request',actionId:'delete-save'})===null);
check('AI proposal rejects other-actor substitution',Dialogue867.validateProposal({intent:'request',actionId:'read',actorId:'other'})===null);
Dialogue867.setInterpreter(()=>({intent:'request',actionId:'delete-save'}));check('Invalid AI proposal falls back safely',Dialogue867.interpret('hello').actionId===null);
Dialogue867.setInterpreter(()=>({intent:'request',actionId:'read'}));check('Raw negation overrides external proposal',Dialogue867.interpret("don't read").intent==='avoid');
Dialogue867.setInterpreter(()=>Promise.resolve({intent:'request',actionId:'read'}));check('Async future provider cannot execute silently',Dialogue867.interpret('hello').intent==='clarify');
Dialogue867.setInterpreter(()=>{throw Error('offline')});check('Provider error yields clarification',Dialogue867.interpret('hello').intent==='clarify');Dialogue867.setInterpreter(null);
const sample={cooperation:{agreeAt:50,negotiateAt:15},dialogue:{responses:{agree:'Aquatic fixture accepts'}}};check('Response policy supports a second personality definition',Dialogue867.chooseResponse({profile:sample,score:80}).text==='Aquatic fixture accepts');
check('Resistance remains the existing handler without new dice rules',autonomyJournal867().includes('Attempt existing resistance')===h63().worn);
reset(0);send('Could we read please?');check('Agreement button is accessible',!!document.querySelector('button[onclick="authorizeDialogue867()"]'));document.querySelectorAll('.autonomy-journal867').forEach(x=>x.open=true);check('New dialogue UI fits mobile width',document.documentElement.scrollWidth<=innerWidth);check('No uncaught browser errors',rootErrors865.length===0);
sessionStorage.setItem('dialogueResults867',JSON.stringify(r));save();return JSON.stringify({results:r,passed:r.filter(x=>x.pass).length,total:r.length});
})();
