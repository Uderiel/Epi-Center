﻿param([string]$Root,[Parameter(Mandatory=$true)][string]$RepoRoot)
$profile=Join-Path $Root ('device-profile-'+[guid]::NewGuid().ToString('N'))
$browser=Start-Process -FilePath 'C:/Program Files/Google/Chrome/Application/chrome.exe' -ArgumentList @('--headless=new','--disable-gpu','--no-first-run','--no-default-browser-check','--disable-background-networking','--remote-debugging-port=0',('--user-data-dir="'+$profile+'"'),'about:blank') -WindowStyle Hidden -PassThru -RedirectStandardError (Join-Path $Root 'device-driver-errors.txt')
$portFile=Join-Path $profile 'DevToolsActivePort'
for($attempt=0;$attempt -lt 50 -and -not(Test-Path -LiteralPath $portFile);$attempt++){Start-Sleep -Milliseconds 100}
if(-not(Test-Path -LiteralPath $portFile)){throw 'Disposable Chrome debugging endpoint unavailable'}
$debugPort=[IO.File]::ReadAllLines($portFile)[0]
$pages=Invoke-RestMethod -Uri ('http://127.0.0.1:'+$debugPort+'/json/list') -TimeoutSec 5
$page=$pages | Where-Object {$_.type -eq 'page'} | Select-Object -First 1
$socket864=[Net.WebSockets.ClientWebSocket]::new()
$socket864.ConnectAsync([uri]$page.webSocketDebuggerUrl,[Threading.CancellationToken]::None).GetAwaiter().GetResult() | Out-Null
$script:sequence864=0
function Send-Cdp864([string]$method,$parameters){
 $script:sequence864++;$sequence=$script:sequence864
 $payload=@{id=$sequence;method=$method;params=$parameters} | ConvertTo-Json -Depth 20 -Compress
 $bytes=[Text.Encoding]::UTF8.GetBytes($payload)
 $socket864.SendAsync([ArraySegment[byte]]::new($bytes),[Net.WebSockets.WebSocketMessageType]::Text,$true,[Threading.CancellationToken]::None).GetAwaiter().GetResult() | Out-Null
 while($true){
  $stream=[IO.MemoryStream]::new();$buffer=New-Object byte[] 65536
  do{$received=$socket864.ReceiveAsync([ArraySegment[byte]]::new($buffer),[Threading.CancellationToken]::None).GetAwaiter().GetResult();$stream.Write($buffer,0,$received.Count)}while(-not $received.EndOfMessage)
  $message=[Text.Encoding]::UTF8.GetString($stream.ToArray()) | ConvertFrom-Json;$stream.Dispose()
  if($message.id -eq $sequence){if($message.error){throw ($message.error | ConvertTo-Json -Compress)};return $message}
 }
}
$serverProcess=$null
try{
 $portFile=Join-Path $Root ('http-port-'+[guid]::NewGuid().ToString('N')+'.txt')
 # Repository root supplied explicitly by release runner.
 $serverProcess=Start-Process -FilePath powershell.exe -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',(Join-Path $Root 'local-server.ps1'),'-RepoRoot',$repoRoot,'-PortFile',$portFile) -WindowStyle Hidden -PassThru -RedirectStandardError (Join-Path $Root 'http-server-errors.txt')
 for($attempt=0;$attempt -lt 50 -and -not(Test-Path $portFile);$attempt++){Start-Sleep -Milliseconds 100}
 if(-not(Test-Path $portFile)){throw 'Local read-only server unavailable'}
 $port=[IO.File]::ReadAllText($portFile);$base='http://127.0.0.1:'+$port+'/Epi-Center/'
 Send-Cdp864 'Emulation.setDeviceMetricsOverride' @{width=390;height=844;deviceScaleFactor=1;mobile=$true} | Out-Null
 Send-Cdp864 'Page.enable' @{} | Out-Null
 Send-Cdp864 'Page.addScriptToEvaluateOnNewDocument' @{source="window.rootErrors865=[];window.addEventListener('error',e=>rootErrors865.push(e.message));"} | Out-Null
 function Navigate-Root865([string]$url){
  Send-Cdp864 'Page.navigate' @{url=$url} | Out-Null
  for($i=0;$i -lt 100;$i++){
   Start-Sleep -Milliseconds 100
   $expectedUrl=$url | ConvertTo-Json -Compress
   try{$ready=Send-Cdp864 'Runtime.evaluate' @{expression="location.href===$expectedUrl&&document.readyState==='complete'&&typeof appearanceUI864==='object'&&Array.isArray(window.rootErrors865)&&document.title.includes('EPI-CENTER')";returnByValue=$true}}catch{if($_.Exception.Message -match 'navigated|context|closed'){continue};throw}
   if($ready.result.result.value){return}
  }
  $diag=Send-Cdp864 'Runtime.evaluate' @{expression="JSON.stringify({url:location.href,title:document.title,errors:window.rootErrors865,text:document.body.innerText.slice(0,700)})";returnByValue=$true}; throw ($diag | ConvertTo-Json -Depth 6)
 }
 $candidate=$base+'epi-center-v0.8.68-manual-acceptance-repairs.html'
 Navigate-Root865 $candidate
 function Eval866([string]$js){
  $r=Send-Cdp864 'Runtime.evaluate' @{expression=$js;returnByValue=$true}
  if($r.result.exceptionDetails){throw ($r.result.exceptionDetails | ConvertTo-Json -Depth 7)}
  return $r.result.result.value
 }

 foreach($mode in @('equipped','inventory','mixed','missing')){
  Eval866 'localStorage.clear();sessionStorage.clear();' | Out-Null
  Navigate-Root865 ($base+'epi-center-v0.8.66-jewelry-storage-and-build-display.html')
  Eval866 @"
document.getElementById('name').value='Legacy $mode Tester';start({preventDefault(){}});
document.getElementById('prof_age').value='34';document.getElementById('prof_gender').value='Male';document.getElementById('prof_hands').value='Legacy original hand description';saveProfile({preventDefault(){}});
const ids=['necklace','earrings','ring-silver','ring-gold','bracelet','belt'];
ids.forEach((id,i)=>{const x=items850().objects[id];x.location='$mode'==='mixed'?['equipped','inventory','closet-accessories'][i%3]:'$mode';x.condition=i%2?'worn':'clean';x.legacyOwnershipMarker='retained-'+id;});
if('$mode'==='missing')ids.forEach(id=>delete s.items850.objects[id]);
items850().objects['bra-ivory'].location='equipped';items850().objects['blouse-white'].location='equipped';s.appearance849={makeup:true};s.gold=937;s.exp=23;s.quest=true;s.questDone=false;h63().influence=37;anatomyInit65().index=5;s.location='tunnel';save();
sessionStorage.setItem('legacyExpected866',JSON.stringify({mode:'$mode',objects:s.items850.objects,original:s.originalAppearance864,original06:s.original06,stats:s.stats,gold:s.gold,exp:s.exp,quest:s.quest,questDone:s.questDone,influence:h63().influence,index:anatomyInit65().index,location:s.location}));
"@ | Out-Null
  Navigate-Root865 $candidate
  $r=Eval866 @"
(function(){const e=JSON.parse(sessionStorage.getItem('legacyExpected866')),results=[];const check=(name,pass)=>{results.push({name:'$mode legacy: '+name,pass:!!pass});if(!pass)throw Error(name);};
for(const id of ['necklace','earrings','ring-silver','ring-gold','bracelet','belt']){
const old=e.objects[id],x=items850().objects[id];
check(id+' preserves existing record or initializes missing storage',old?JSON.stringify(x)===JSON.stringify(old):x.location==='closet-accessories'&&x.condition==='clean');
}
check('Unrelated object records preserved',Object.entries(e.objects).every(([id,x])=>JSON.stringify(items850().objects[id])===JSON.stringify(x)));
check('Identity archives and attribute values preserved',JSON.stringify(s.originalAppearance864)===JSON.stringify(e.original)&&JSON.stringify(s.original06)===JSON.stringify(e.original06)&&JSON.stringify(s.stats)===JSON.stringify(e.stats));
check('Progress and transformation preserved',s.gold===e.gold&&s.exp===e.exp&&s.quest===e.quest&&s.questDone===e.questDone&&h63().influence===e.influence&&anatomyInit65().index===e.index&&s.location===e.location);
const template=document.createElement('template');template.innerHTML=equipment67();const fields=Array.from(template.content.querySelectorAll('details.card')).filter(x=>['Head','Neck','Torso','Arms','Hands','Hips','Legs','Feet'].includes(x.querySelector('summary b')?.textContent));
check('Existing equipped jewelry appears in every correct body-region field',fields.length>=8&&['necklace','earrings','ring-silver','ring-gold','bracelet','belt'].every(id=>fields.every(x=>x.querySelector('summary').textContent.includes(item850(id).name)===(items850().objects[id].location==='equipped'&&x.querySelector('summary b').textContent===({necklace:'Neck',earrings:'Head','ring-silver':'Hands','ring-gold':'Hands',bracelet:'Arms',belt:'Hips'})[id]))));
check('Layered clothing and makeup remain displayed',fields.filter(x=>x.querySelector('summary b').textContent==='Torso').every(x=>x.textContent.includes(item850('bra-ivory').name)&&x.textContent.includes(item850('blouse-white').name))&&fields.filter(x=>x.querySelector('summary b').textContent==='Head').every(x=>x.textContent.includes('Everyday makeup')));
check('Same save key and no uncaught browser errors',FOUNDATION_KEY==='epicenter_foundation_v060'&&rootErrors865.length===0);
sessionStorage.setItem('legacyObjects866',JSON.stringify(items850().objects));
sessionStorage.setItem('legacyResults866',JSON.stringify(results));save();return JSON.stringify(results);})();
"@
  Navigate-Root865 $candidate
  $r=Eval866 @"
(function(){const r=JSON.parse(sessionStorage.getItem('legacyResults866')),pass=JSON.stringify(items850().objects)===sessionStorage.getItem('legacyObjects866')&&rootErrors865.length===0;r.push({name:'$mode legacy: real reload does not relocate or recreate accessories',pass});if(!pass)throw Error('Legacy reload');return JSON.stringify(r);})();
"@
  $row=$r | ConvertFrom-Json
  if(-not $script:allResults866){$script:allResults866=@()}
  $script:allResults866+=@($row)
 }
 [IO.File]::WriteAllText((Join-Path $Root 'legacy-results.json'),($script:allResults866 | ConvertTo-Json -Depth 8))
 'Existing-save checks: '+($script:allResults866 | Where-Object pass).Count+'/'+$script:allResults866.Count
}finally{
 if($socket864.State -eq [Net.WebSockets.WebSocketState]::Open){try{Send-Cdp864 'Browser.close' @{} | Out-Null}catch{}}
 $socket864.Dispose();if($serverProcess -and -not $serverProcess.HasExited){Stop-Process -Id $serverProcess.Id}
}
