﻿param([string]$Root,[Parameter(Mandatory=$true)][string]$RepoRoot)
$profile=Join-Path $Root ('device-profile-'+[guid]::NewGuid().ToString('N'))
$browser=Start-Process -FilePath 'C:/Program Files/Google/Chrome/Application/chrome.exe' -ArgumentList @('--headless=new','--disable-gpu','--no-first-run','--no-default-browser-check','--disable-background-networking','--remote-debugging-port=0',('--user-data-dir="'+$profile+'"'),'about:blank') -WindowStyle Hidden -PassThru -RedirectStandardError (Join-Path $Root 'device-driver-errors.txt')
$portFile=Join-Path $profile 'DevToolsActivePort'
for($attempt=0;$attempt -lt 50 -and -not(Test-Path -LiteralPath $portFile);$attempt++){Start-Sleep -Milliseconds 100}
if(-not(Test-Path -LiteralPath $portFile)){throw 'Disposable Chrome debugging endpoint unavailable'}
$debugPort=[IO.File]::ReadAllLines($portFile)[0]
$pages=Invoke-RestMethod -Uri ('http://127.0.0.1:'+$debugPort+'/json/list') -TimeoutSec 5
$page=$pages | Where-Object {$_.type -eq 'page'} | Select-Object -First 1
$socket864=[Net.WebSockets.ClientWebSocket]::new()
$socket864.ConnectAsync([uri]$page.webSocketDebuggerUrl,[Threading.CancellationToken]::None).GetAwaiter().GetResult() | Out-Null
$script:sequence864=0
function Send-Cdp864([string]$method,$parameters){
 $script:sequence864++;$sequence=$script:sequence864
 $payload=@{id=$sequence;method=$method;params=$parameters} | ConvertTo-Json -Depth 20 -Compress
 $bytes=[Text.Encoding]::UTF8.GetBytes($payload)
 $socket864.SendAsync([ArraySegment[byte]]::new($bytes),[Net.WebSockets.WebSocketMessageType]::Text,$true,[Threading.CancellationToken]::None).GetAwaiter().GetResult() | Out-Null
 while($true){
  $stream=[IO.MemoryStream]::new();$buffer=New-Object byte[] 65536
  do{$received=$socket864.ReceiveAsync([ArraySegment[byte]]::new($buffer),[Threading.CancellationToken]::None).GetAwaiter().GetResult();$stream.Write($buffer,0,$received.Count)}while(-not $received.EndOfMessage)
  $message=[Text.Encoding]::UTF8.GetString($stream.ToArray()) | ConvertFrom-Json;$stream.Dispose()
  if($message.id -eq $sequence){if($message.error){throw ($message.error | ConvertTo-Json -Compress)};return $message}
 }
}
$serverProcess=$null
try{
 $portFile=Join-Path $Root ('http-port-'+[guid]::NewGuid().ToString('N')+'.txt')
 # Repository root supplied explicitly by release runner.
 $serverProcess=Start-Process -FilePath powershell.exe -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',(Join-Path $Root 'local-server.ps1'),'-RepoRoot',$repoRoot,'-PortFile',$portFile) -WindowStyle Hidden -PassThru -RedirectStandardError (Join-Path $Root 'http-server-errors.txt')
 for($attempt=0;$attempt -lt 50 -and -not(Test-Path $portFile);$attempt++){Start-Sleep -Milliseconds 100}
 if(-not(Test-Path $portFile)){throw 'Local read-only server unavailable'}
 $port=[IO.File]::ReadAllText($portFile);$base='http://127.0.0.1:'+$port+'/Epi-Center/'
 Send-Cdp864 'Emulation.setDeviceMetricsOverride' @{width=390;height=844;deviceScaleFactor=1;mobile=$true} | Out-Null
 Send-Cdp864 'Page.enable' @{} | Out-Null
 Send-Cdp864 'Page.addScriptToEvaluateOnNewDocument' @{source="window.rootErrors865=[];window.addEventListener('error',e=>rootErrors865.push(e.message));"} | Out-Null
 function Navigate-Root865([string]$url){
  Send-Cdp864 'Page.navigate' @{url=$url} | Out-Null
  for($i=0;$i -lt 100;$i++){
   Start-Sleep -Milliseconds 100
   $expectedUrl=$url | ConvertTo-Json -Compress
   try{$ready=Send-Cdp864 'Runtime.evaluate' @{expression="location.href===$expectedUrl&&document.readyState==='complete'&&typeof appearanceUI864==='object'&&Array.isArray(window.rootErrors865)&&document.title.includes('v0.8.68')";returnByValue=$true}}catch{if($_.Exception.Message -match 'navigated|context|closed'){continue};throw}
   if($ready.result.result.value){return}
  }
  $diag=Send-Cdp864 'Runtime.evaluate' @{expression="JSON.stringify({url:location.href,title:document.title,errors:window.rootErrors865,text:document.body.innerText.slice(0,700)})";returnByValue=$true}; throw ($diag | ConvertTo-Json -Depth 6)
 }
 $candidate=$base+'epi-center-v0.8.68-manual-acceptance-repairs.html'
 Navigate-Root865 $candidate
 function Eval866([string]$js){
  $r=Send-Cdp864 'Runtime.evaluate' @{expression=$js;returnByValue=$true}
  if($r.result.exceptionDetails){throw ($r.result.exceptionDetails | ConvertTo-Json -Depth 7)}
  return $r.result.result.value
 }
 $setup=@"
window.results866=[];
window.check866=(name,ok)=>{results866.push({name,pass:!!ok});if(!ok)throw Error(name+'; '+document.getElementById('app').innerText.slice(-3000));};
window.click866=(code)=>{const b=Array.from(document.querySelectorAll('button')).find(x=>x.getAttribute('onclick')===code&&!x.disabled);if(!b)throw Error('Missing button '+code+'; text '+document.getElementById('app').innerText.slice(-1200));b.click();};
check866('All inline JavaScript compiles',Array.from(document.scripts).every(x=>{if(!x.src)new Function(x.textContent);return true;}));
check866('Single current build and local save labels',document.querySelector('.sidefoot').innerText.includes('BUILD: 0.8.68')&&document.querySelector('.sidefoot').innerText.includes('SESSION: LOCAL SAVE')&&document.querySelector('.foot').innerText.includes('Build 0.8.68')&&!document.body.innerText.includes('0.6.3 CURSED EQUIPMENT')&&!document.body.innerText.includes('LOCAL PROTOTYPE'));
document.getElementById('name').value='Jewelry Fresh Tester';start({preventDefault(){}});
check866('All 19 appearance inputs available',APPEARANCE_FIELDS864.length===19&&APPEARANCE_FIELDS864.every(x=>x.keys.every(k=>!!document.getElementById('prof_'+k))));
document.getElementById('prof_age').value='31';document.getElementById('prof_gender').value='Male';document.getElementById('prof_hands').value='Original hands retained';saveProfile({preventDefault(){}});
check866('Original identity archives save',s.profileComplete&&baseline67('hands')==='Original hands retained');
check866('Five unique jewelry objects plus existing belt',closetAccessories866().length===6&&new Set(CATALOG850.map(x=>x.id)).size===CATALOG850.length);
check866('Fresh accessories stored not carried or equipped',closetAccessories866().every(d=>items850().objects[d.id].location==='closet-accessories'&&!s.inventory[d.name]));
check866('Stored jewelry absent from active equipment rows',!equipment67().includes("accessory855('equip','necklace')")&&!inventory().includes("accessory855('equip','necklace')"));
accessory855('equip','necklace');check866('Remote equip of stored accessory blocked',items850().objects.necklace.location==='closet-accessories');
// Apartment fixture isolates closet controls; no residence permission code is bypassed in the candidate.
s.location='erinhome';s.screen='play69';roomState835().room='closet';ui838().room='closet';ui838().view='private848';ui838().object='accessories';home848().focus=true;render();
check866('Existing closet section renders every accessory',closetAccessories866().every(d=>Array.from(document.querySelectorAll('button')).some(b=>b.getAttribute('onclick')==="itemAction850('select','"+d.id+"')")));
sessionStorage.setItem('results866',JSON.stringify(results866));
"@
 Eval866 $setup | Out-Null
 $ids=@('necklace','earrings','ring-silver','ring-gold','bracelet','belt')
 foreach($id in $ids){
  foreach($phase in @('take','equip','remove','return')){
   $js=@"
window.results866=JSON.parse(sessionStorage.getItem('results866'));
window.check866=(name,ok)=>{results866.push({name,pass:!!ok});if(!ok)throw Error(name+'; '+document.getElementById('app').innerText.slice(-3000));};
window.click866=(code)=>{const b=Array.from(document.querySelectorAll('button')).find(x=>x.getAttribute('onclick')===code&&!x.disabled);if(!b)throw Error('Missing button '+code+'; text '+document.getElementById('app').innerText.slice(-1400));b.click();};
const id='$id',phase='$phase',obj=items850().objects[id],condition=obj.condition;
if(phase==='take'){homeOpen848('accessories');click866("itemAction850('select','"+id+"')");click866("itemAction850('carry','"+id+"')");}
else if(phase==='equip'){click866("accessory855('equip','"+id+"')");}
else if(phase==='remove'){setScreen('equipment67');const region={necklace:'Neck',earrings:'Head','ring-silver':'Hands','ring-gold':'Hands',bracelet:'Arms',belt:'Hips'}[id];const field=Array.from(document.querySelectorAll('details.card')).find(x=>x.querySelector('summary b')?.textContent===region);if(!field)throw Error('Missing equipment region '+region);field.open=true;const button=Array.from(field.querySelectorAll('button')).find(b=>b.getAttribute('onclick')==="accessory855('remove','"+id+"')" );if(!button)throw Error('Missing region Unequip control '+id);button.click();setScreen('play69');}
else click866("accessory855('return','"+id+"')");
const expected=phase==='equip'?'equipped':phase==='return'?'closet-accessories':'inventory';
check866(id+' '+phase+' updates one object; condition unchanged',items850().objects[id]===obj&&obj.location===expected&&obj.condition===condition&&CATALOG850.filter(d=>d.id===id).length===1);
check866(id+' '+phase+' closet list matches location',itemList850('closet-accessories').includes("itemAction850('select','"+id+"')")===(expected==='closet-accessories'));
check866(id+' '+phase+' equipment and inventory controls agree',equipment67().includes("accessory855('"+(expected==='equipped'?'remove':'equip')+"','"+id+"')")===(expected!=='closet-accessories')&&inventory().includes("accessory855('equip','"+id+"')")===(expected==='inventory'));
setScreen('equipment67');
const expectedRegion={necklace:'Neck',earrings:'Head','ring-silver':'Hands','ring-gold':'Hands',bracelet:'Arms',belt:'Hips'}[id];
const fields=Array.from(document.querySelectorAll('details.card')).filter(x=>['Head','Neck','Torso','Arms','Hands','Hips','Legs','Feet'].includes(x.querySelector('summary b')?.textContent));
check866(id+' '+phase+' correct region summaries',fields.length>=8&&fields.every(x=>x.querySelector('summary').textContent.includes(item850(id).name)===(expected==='equipped'&&x.querySelector('summary b').textContent===expectedRegion)));
check866(id+' '+phase+' correct region removal controls',fields.every(x=>!!Array.from(x.querySelectorAll('button')).find(b=>b.getAttribute('onclick')==="accessory855('remove','"+id+"')")===(expected==='equipped'&&x.querySelector('summary b').textContent===expectedRegion)));
fields.forEach(x=>x.open=true);
check866(id+' '+phase+' Equipment layout fits Android width',document.documentElement.scrollWidth<=innerWidth);
setScreen('inventory');check866(id+' '+phase+' Inventory layout fits Android width',document.documentElement.scrollWidth<=innerWidth);
setScreen('play69');const beforeTrip=JSON.stringify(obj);s.location='hub';render();s.location='erinhome';render();check866(id+' '+phase+' panels and locations preserve physical object',JSON.stringify(items850().objects[id])===beforeTrip);
check866(id+' '+phase+' Android layout fits',document.documentElement.scrollWidth<=innerWidth);
save();sessionStorage.setItem('expect866',JSON.stringify({id,phase,expected,object:obj,name:s.name,original:s.originalAppearance864}));sessionStorage.setItem('results866',JSON.stringify(results866));
"@
   Eval866 $js | Out-Null
   Navigate-Root865 $candidate
   Eval866 @"
const e=JSON.parse(sessionStorage.getItem('expect866')),r=JSON.parse(sessionStorage.getItem('results866'));
r.push({name:e.id+' '+e.phase+' real reload preserves object, identity and archive',pass:JSON.stringify(items850().objects[e.id])===JSON.stringify(e.object)&&s.name===e.name&&JSON.stringify(s.originalAppearance864)===JSON.stringify(e.original)&&rootErrors865.length===0});
if(!r[r.length-1].pass)throw Error(r[r.length-1].name);
sessionStorage.setItem('results866',JSON.stringify(r));
"@ | Out-Null
  }
 }
 $report=Eval866 "JSON.stringify({results:JSON.parse(sessionStorage.getItem('results866')),errors:rootErrors865,viewport:{width:innerWidth,height:innerHeight}})"
 [IO.File]::WriteAllText((Join-Path $Root 'fresh-results.json'),$report)
 $d=$report | ConvertFrom-Json; 'Fresh checks: '+($d.results | Where-Object pass).Count+'/'+$d.results.Count
}finally{
 if($socket864.State -eq [Net.WebSockets.WebSocketState]::Open){try{Send-Cdp864 'Browser.close' @{} | Out-Null}catch{}}
 $socket864.Dispose();if($serverProcess -and -not $serverProcess.HasExited){Stop-Process -Id $serverProcess.Id}
}