Final contextual candidate verification. Extract outside the repository. Windows PowerShell and Chrome required.
Run run-all.ps1 -RepoRoot <checkout>. Use its printed Results directory as -Root for acceptance-driver.ps1 and acceptance-360-driver.ps1 (81 checks each).
Copy context-tests.js into that Results directory, then run context-driver.ps1 -Root <Results directory> -RepoRoot <checkout> (52 checks). This suite needs access to the actual GitHub Pages app to verify origin isolation; it never transfers saves. All browser writes use disposable profiles.
The 13-suite regression summary records 616 overlapping assertions. Diagnostic baseline/repaired traces are historical; repaired-repro-driver records the earlier C20EA2 checkpoint, not the final contextual decision policy.
No personal profiles, login data or real player saves are included.
Final candidate SHA-256: AA8A8C08A8C63460AFBFE6225A7B5865ACA38A2C49DEF85B1DC6A2E7C17D713C